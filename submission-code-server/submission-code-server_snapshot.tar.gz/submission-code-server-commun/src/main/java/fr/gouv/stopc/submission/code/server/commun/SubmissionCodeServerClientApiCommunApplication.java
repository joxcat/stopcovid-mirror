package fr.gouv.stopc.submission.code.server.commun;

public class SubmissionCodeServerClientApiCommunApplication {

	public static void main(String[] args) {
		
	}

}
