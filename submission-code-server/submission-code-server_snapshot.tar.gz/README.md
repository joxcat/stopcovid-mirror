# Submission Code Server

Ce projet gitlab.inria.fr est un des composants de la solution plus globale [StopCovid](https://gitlab.inria.fr/stopcovid19/accueil/-/blob/master/README.md).

Ce composant propose les services suivants :
* génération de codes courts et longs : pour les professionnels de santé (laboratoires, médecins...)
* vérification et consommation de codes par la partie de la plateforme StopCovid

