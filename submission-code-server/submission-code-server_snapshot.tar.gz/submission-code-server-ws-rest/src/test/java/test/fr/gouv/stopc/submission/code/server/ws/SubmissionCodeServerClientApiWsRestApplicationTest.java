package test.fr.gouv.stopc.submission.code.server.ws;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
class SubmissionCodeServerClientApiWsRestApplicationTest {

	@Test
	void testContextLoads() {
	}

}
