package fr.gouv.stopc.submission.code.server.database;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SubmissionCodeServerClientApiDatabaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(SubmissionCodeServerClientApiDatabaseApplication.class, args);
	}

}
