Ce composant à été écrit par
* Groupe Capgemini (Capgemini, Idean, Sogeti)

Les personnes suivantes ont contribué
* Pour Groupe Capgemini (Capgemini, Idean, Sogeti)
    * redford.stopcovid@idean.com
    * palmer.stopcovid@capgemini.com
