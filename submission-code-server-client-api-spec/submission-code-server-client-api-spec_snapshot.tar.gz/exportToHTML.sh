#!/bin/bash
redoc-cli bundle -o swagger.html swagger.yml