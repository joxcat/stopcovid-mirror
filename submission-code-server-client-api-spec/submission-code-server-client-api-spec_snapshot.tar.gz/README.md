# Submission Code Server Client API

Ce projet gitlab.inria.fr est un des composants de la solution plus globale [StopCovid](https://gitlab.inria.fr/stopcovid19/accueil/-/blob/master/README.md).

Ce composant spécifie l'API cliente du [Submission Code Server](https://gitlab.inria.fr/stopcovid19/submission-code-server).
